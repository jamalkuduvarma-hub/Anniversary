const openBtn = document.getElementById("openBtn");
const story = document.getElementById("story");
const hearts = document.getElementById("hearts");

openBtn.addEventListener("click", () => {
  story.classList.remove("hidden");
  document.body.classList.add("story-open");
  setTimeout(() => {
    document.getElementById("story").scrollIntoView({ behavior: "smooth" });
  }, 80);
  startHearts();
  observeReveals();
});

function observeReveals() {
  const items = document.querySelectorAll(".reveal");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  items.forEach((item) => observer.observe(item));
}

function startHearts() {
  setInterval(() => {
    createHeart();
  }, 900);
}

function createHeart() {
  const heart = document.createElement("span");
  heart.className = "float-heart";
  heart.textContent = Math.random() > 0.35 ? "♡" : "♥";

  const size = 12 + Math.random() * 18;
  const duration = 7 + Math.random() * 7;

  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${size}px`;
  heart.style.animationDuration = `${duration}s`;

  hearts.appendChild(heart);

  setTimeout(() => heart.remove(), duration * 1000 + 500);
}

document.querySelectorAll(".reveal").forEach((el) => {
  if (el.getBoundingClientRect().top < window.innerHeight * 0.85) {
    el.classList.add("visible");
  }
});
