# For My Bangaram ❤️

A mobile-first anniversary website for Vishal & Chakrika.

## Files

- `index.html` — complete website content
- `style.css` — romantic responsive design and animations
- `script.js` — scroll reveals and floating hearts

## Run locally

1. Keep all three files in the same folder.
2. Double-click `index.html`, or open it in a browser.
3. For the smoothest experience, use Chrome/Edge on a phone or desktop.

No backend, database, API, photos, or music are required.

## Important

The story and messages in `index.html` are based on Vishal's own wording. You can edit any sentence directly in the HTML if you want to correct spelling or add/remove a memory.

The final screen intentionally does not contain an AI-written proposal. It ends with:

"A year with full of ups and downs, but I still choose you — whatever the situation may be, however you may be.

Happy Anniversary ❤️🫶🫶🫶

With love,
your Bangaram (Vishu)"

Then it says that some things are better said in person.
